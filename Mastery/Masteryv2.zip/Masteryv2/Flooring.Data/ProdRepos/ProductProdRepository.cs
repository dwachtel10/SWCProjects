﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Flooring.Models;

namespace Flooring.Data.ProdRepos
{
    class ProductProdRepository : IProductRepository
    {
        public Dictionary<string, Product> ListProducts()
        {
            throw new NotImplementedException();
        }

        public Product GetProduct(string ProductType)
        {
            throw new NotImplementedException();
        }
    }
}
