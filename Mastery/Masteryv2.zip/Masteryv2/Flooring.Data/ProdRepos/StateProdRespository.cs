﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Flooring.Models;

namespace Flooring.Data.ProdRepos
{
    class StateProdRespository : IStateRepository

    {
        Dictionary<string, State> states = new Dictionary<string, State>();

        public Dictionary<string, State> ListState(string StateName)
        {
            throw new NotImplementedException();
        }

        public State GetState(string StateName)
        {
            throw new NotImplementedException();
        }
    }
}
