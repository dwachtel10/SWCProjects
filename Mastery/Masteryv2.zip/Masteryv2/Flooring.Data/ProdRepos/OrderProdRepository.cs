﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Flooring.Models;

namespace Flooring.Data.ProdRepos
{
    public class OrderProdRepository : IOrderRepository
    {
        private const string FILENAME = @"DataFiles\Orders_";
        private const string FILEEXT = ".txt";



        //public OrderProdRepository(string filepath)
        //{
        //    _filePath = filepath;
        //}

        //public List<Order> List()
        //{
        //    List<Order> orders = new List<Order>();

        //    using (StreamReader sr = new StreamReader(_filePath))
        //    {
        //        sr.ReadLine();
        //        string line;

        //        while ((line = sr.ReadLine())
        //               != null)
        //        {
        //            Order newOrder = new Order();

        //            string[] columns = line.Split(',');

        //            newOrder.OrderNumber = int.Parse(columns[0]);
        //            newOrder.CustomerName = columns[1];
        //            newOrder.StateName = columns[2];
        //            newOrder.ProductType = columns[3];
        //            newOrder.Area = decimal.Parse(columns[4]);

        //            orders.Add(newOrder);
        //        }
        //    }
        //    return orders;
        //}

        public void AddOrder(DateTime Date, Order order)
        {
            //using (StreamWriter sw = new StreamWriter(_filePath, true))
            //{
            //    string line = CreateCsvForOrder(order);
            //    sw.WriteLine(line);
            //}
            var orders = ReadFromFile(order.OrderDate);
            orders.Add(order);

            var fileName = FILENAME + order.OrderDate + FILEEXT;

            WriteToFile(orders, fileName);

            


        }

        public void EditOrder(Order order, Order editedOrder)
        {
            //orders.Add(editedOrder);
            //_filePath.Remove(order);
            var orders = ReadFromFile(order.OrderDate);
            var orderToRemove = orders.FirstOrDefault(a => a.OrderNumber == order.OrderNumber);
            orders.Remove(orderToRemove);
            orders.Add(order);
            orders = orders.OrderBy(a => a.OrderNumber).ToList();

            var fileName = FILENAME + order.OrderDate + FILEEXT;

            WriteToFile(orders, fileName);

           
        }

        public void DeleteOrder(Order order)
        {
            //var orderToDelete = 
            //    from o in 

        }

        public List<Order> ListOrdersByDate(DateTime Date)
        {
            var accounts = ReadFromFile(Date);
            return accounts;
        }

        //public int GetOrderNumber(DateTime Date)
        //{
        //    bool ordersForToday = (_filePath.Where(o => o.OrderDate == Date).Count()) != 0;
        //    if (ordersForToday)
        //    {
        //        return _filePath.Where(o => o.OrderDate == Date).Max(o => o.OrderNumber) + 1;
        //    }
        //    else
        //    {
        //        return 1;
        //    }

        //}

        private string CreateCsvforOrder(Order order)
        {
            return string.Format($"#{order.OrderNumber}, {order.CustomerName}, {order.ProductType}, {order.Area}");
        }

        private List<Order> ReadFromFile(DateTime Date)
        {
            var fileName = FILENAME + Date + FILEEXT;

            List<Order> orders = new List<Order>();

            if (File.Exists(fileName))
            {
                using (StreamReader sr = File.OpenText(fileName))
                {
                    sr.ReadLine();

                    string inputLine = "";
                    while ((inputLine = sr.ReadLine()) != null)
                    {
                        string[] inputParts = inputLine.Split(',');
                        Order newOrder = new Order()
                        {
                            OrderNumber = int.Parse(inputParts[0]),
                            CustomerName = inputParts[1],
                            StateName = inputParts[2],
                            ProductType = inputParts[3],
                            Area = decimal.Parse(inputParts[4])

                        };

                        orders.Add(newOrder);
                    }
                }
            }

            return orders;
        }

        public void WriteToFile(List<Order> orders, string FileName)
        {
            using (StreamWriter sw = new StreamWriter(FileName, false))
            {
                sw.WriteLine("ORDER NUMBER,CUSTOMER NAME,STATE,PRODUCT,AREA");

                foreach (var order in orders)
                {
                    sw.WriteLine($"{order.OrderNumber},{order.CustomerName},{order.StateName},{order.ProductType},{order.Area}");
                }
            }
        }
    }
}
