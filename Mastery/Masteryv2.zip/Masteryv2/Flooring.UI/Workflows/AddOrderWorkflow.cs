﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Flooring.BLL;
using Flooring.Data.TestRepos;
using Flooring.Models;

namespace Flooring.UI.Workflows
{
    public class AddOrderWorkflow
    {
        public void Execute()
        {
            OrderManager manager = new OrderManager();

            Console.Clear();
            Console.WriteLine("Add New Order");
            Console.WriteLine(ConsoleIO.HorizontalLine);

            Order order = new Order();
            order.OrderDate = DateTime.Today;

            State state = new State();
            Product product = new Product();

            
            order.CustomerName = ConsoleIO.GetRequiredStringFromUser("Customer Name: ");
            order.StateName = ConsoleIO.GetRequiredStringFromUser("State: ");
            order.ProductType = ConsoleIO.GetRequiredStringFromUser("What product?");
            order.Area = ConsoleIO.GetRequiredDecimalFromUser("How much area, in square feet, are you planning to cover?: ");

            
            Console.WriteLine();
            Console.WriteLine(ConsoleIO.HorizontalLine);

            Console.WriteLine($"{order.CustomerName}, {order.StateName}, {order.ProductType}, {order.Area}");

            if (ConsoleIO.GetYesNoAnswerFromuser("Add the following information?") == "Y")
            {
                OrderTestRepository repo = new OrderTestRepository();
                repo.AddOrder(DateTime.Today, 
                    order);
                //repo.GetOrderNumber();
                
                Console.WriteLine("Order Added.");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Add order cancelled.");
                Console.ReadLine();
            }
            Console.Clear();
            MainMenu.Main();
        }
    }
}
