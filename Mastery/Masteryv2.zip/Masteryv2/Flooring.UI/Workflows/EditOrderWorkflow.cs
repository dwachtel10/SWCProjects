﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Flooring.BLL;
using Flooring.Models;
using Flooring.Models.Responses;

namespace Flooring.UI.Workflows
{
    public class EditOrderWorkflow
    {
        public void Execute()
        {
            List<Order> resultsList = new List<Order>();
            OrderManager manager = new OrderManager();
            Order editedOrder = new Order();
            Console.Clear();
            Console.WriteLine("Edit Order Data");
            Console.WriteLine(ConsoleIO.HorizontalLine);
            DateTime date = ConsoleIO.GetRequiredDateTimeFromUser("Enter the date of the order: ");

            ViewOrderResponses response = manager.ViewOrders(date);

            if (response.orders == null)
            {
                Console.WriteLine("No orders found for that date.");
                Console.WriteLine("Press any key to return to the Main Menu.");
                Console.ReadKey();
                Console.Clear();
                MainMenu.Main();
            }


            foreach (var order in
                response.orders)
            {

                ConsoleIO.DisplayOrderDetails(order);
                resultsList.Add(order);
                Console.ReadLine();

            }


            int selection = ConsoleIO.GetRequiredIntFromUser("Please enter the number of the order you'd like to edit: ");
        var selectedOrder = from o in resultsList
                            where o.OrderNumber == selection
                            select o;
            Order editOrder = selectedOrder.FirstOrDefault();

            Console.WriteLine("Press enter to keep the existing value.", editOrder);
            editedOrder.OrderDate = editOrder.OrderDate;
            editedOrder.CustomerName = ConsoleIO.GetEditStringName($"Enter the new customer name ({editOrder.CustomerName}):", editOrder);
            editedOrder.StateName = ConsoleIO.GetEditState($"Enter the new state ({editOrder.StateName}):", editOrder);
            editedOrder.ProductType= ConsoleIO.GetEditProduct($"Enter the new product to be ordered ({editOrder.ProductType}):", editOrder);
            editedOrder.Area = ConsoleIO.GetEditArea($"Enter the new square footage to be covered ({editOrder.Area}):", editOrder);
            editedOrder.OrderNumber = editOrder.OrderNumber;

           



            manager.EditOrder(date, editOrder, editedOrder);
            MainMenu.Main();

        }


    }
}
